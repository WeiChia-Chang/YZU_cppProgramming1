#include <iostream>
#include <fstream>
using namespace::std;

int main()
{
   system( "mode con cols=30 lines=20" );
   system( "color F0" );

   ofstream outFile( "strings.txt", ios::out );

   if( !outFile )
   {
      cout << "File could not be opened" << endl;
      system( "pause" );
      exit( 1 );
   }

   char string1[] = "abcd";
   char string2[] = "efgh";
   char string3[] = "ijkl";
   outFile << string1 << endl;
   outFile << string2 << endl;
   outFile << string3 << endl;

   outFile.close();

   ifstream inFile( "strings.txt", ios::in );

   if( !inFile )
   {
      cout << "File could not be opened" << endl;
      system( "pause" );
      exit( 1 );
   }

	char str[ 10 ];

	inFile >> str;

   cout << "good(): " << boolalpha << inFile.good() << endl;
   cout << " eof(): " << boolalpha << inFile.eof() << endl;
   cout << "fail(): " << boolalpha << inFile.fail() << endl;
   cout << " bad(): " << boolalpha << inFile.bad() << endl << endl;

   cout << str << endl << endl;

//	inFile.ignore();

	inFile.get( str, 10, '\n' );

   cout << "good(): " << boolalpha << inFile.good() << endl;
   cout << " eof(): " << boolalpha << inFile.eof() << endl;
   cout << "fail(): " << boolalpha << inFile.fail() << endl;
   cout << " bad(): " << boolalpha << inFile.bad() << endl << endl;

   cout << str << endl << endl;

   inFile.close();

	system("pause");
}